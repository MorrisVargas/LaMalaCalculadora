using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

namespace BadCalcVeryBad
{
    /// <summary>
    /// Maneja el historial de c�lculos en memoria y en archivo.
    /// </summary>
    public class CalculationHistory
    {
        private readonly List<string> _entries = new();
        public IReadOnlyList<string> Entries => _entries;
        public int Counter { get; private set; }

        public void Add(string entry)
        {
            _entries.Add(entry);
            Counter++;
        }
    }

    /// <summary>
    /// Calculadora con operaciones b�sicas.
    /// </summary>
    public class ShoddyCalc
    {
        // Tolerancia para comparar con cero
        private const double Epsilon = 1e-9;

        private static bool IsApproximatelyZero(double value) =>
            Math.Abs(value) < Epsilon;

        public double DoOperation(double a, double b, string op)
        {
            return op switch
            {
                "+" => a + b,
                "-" => a - b,
                "*" => a * b,

                // Divisi�n: usar rango en vez de igualdad exacta
                "/" => IsApproximatelyZero(b)
                    ? double.NaN
                    : a / b,

                "^" => Math.Pow(a, b),

                // M�dulo: igual, usar rango
                "%" => IsApproximatelyZero(b)
                    ? double.NaN
                    : a % b,

                _ => double.NaN
            };
        }
    }

    class Program
    {
        private static readonly ShoddyCalc _calculator = new();
        private static readonly CalculationHistory _history = new();
        private const string HistoryFileName = "history.txt";

        static void Main(string[] args)
        {
            bool exit = false;

            while (!exit)
            {
                ShowMenu();
                var option = Console.ReadLine();

                switch (option)
                {
                    case "0":
                        exit = true;
                        break;

                    case "1": // suma
                    case "2": // resta
                    case "3": // mul
                    case "4": // div
                    case "5": // pow
                    case "6": // mod
                        ExecuteBinaryOperation(option);
                        break;

                    case "7": // sqrt
                        ExecuteSqrt();
                        break;

                    case "9": // historial
                        PrintHistory();
                        break;

                    default:
                        Console.WriteLine("Opci�n no v�lida.");
                        break;
                }

                Console.WriteLine();
            }

            SaveHistoryToTempFile();
        }

        #region Men� y flujo

        private static void ShowMenu()
        {
            Console.WriteLine("BAD CALC - refactorizada");
            Console.WriteLine("1) add  2) sub  3) mul  4) div  5) pow  6) mod  7) sqrt  9) hist  0) exit");
            Console.Write("opt: ");
        }

        private static void ExecuteBinaryOperation(string option)
        {
            if (!TryReadOperands(out double a, out double b))
            {
                Console.WriteLine("No se pudieron leer los operandos.");
                return;
            }

            string op = option switch
            {
                "1" => "+",
                "2" => "-",
                "3" => "*",
                "4" => "/",
                "5" => "^",
                "6" => "%",
                _ => ""
            };

            if (string.IsNullOrEmpty(op))
            {
                Console.WriteLine("Operaci�n no reconocida.");
                return;
            }

            if (op == "/" && IsApproximatelyZero(b))
            {
                Console.WriteLine("No se puede dividir por cero.");
                return;
            }

            if ((op == "%" || op == "/") && IsApproximatelyZero(b))
            {
                Console.WriteLine("El segundo operando no puede ser cero.");
                return;
            }

            double result = _calculator.DoOperation(a, b, op);
            PrintAndStoreResult(a.ToString(CultureInfo.InvariantCulture),
                                b.ToString(CultureInfo.InvariantCulture),
                                op,
                                result);
        }

        private static void ExecuteSqrt()
        {
            Console.Write("a: ");
            var input = Console.ReadLine();

            if (!TryParseDouble(input, out double value))
            {
                Console.WriteLine("Valor no v�lido.");
                return;
            }

            if (value < 0)
            {
                Console.WriteLine("No se puede calcular la ra�z cuadrada de un n�mero negativo.");
                return;
            }

            double result = Math.Sqrt(value);
            PrintAndStoreResult(value.ToString(CultureInfo.InvariantCulture),
                                "N/A",
                                "sqrt",
                                result);
        }

        private static void PrintHistory()
        {
            if (_history.Entries.Count == 0)
            {
                Console.WriteLine("No hay registros en el historial.");
                return;
            }

            Console.WriteLine("Historial de operaciones:");
            foreach (var entry in _history.Entries)
            {
                Console.WriteLine(entry);
            }
        }

        #endregion

        #region Parsing y utilidades

        private static bool TryReadOperands(out double a, out double b)
        {
            Console.Write("a: ");
            var aText = Console.ReadLine();
            Console.Write("b: ");
            var bText = Console.ReadLine();

            bool okA = TryParseDouble(aText, out a);
            bool okB = TryParseDouble(bText, out b);

            if (!okA || !okB)
            {
                Console.WriteLine("Uno o ambos operandos no son v�lidos.");
                return false;
            }

            return true;
        }

        private static bool TryParseDouble(string text, out double value)
        {
            if (text is null)
            {
                value = 0;
                return false;
            }

            text = text.Replace(',', '.');
            return double.TryParse(
                text,
                NumberStyles.Float,
                CultureInfo.InvariantCulture,
                out value);
        }

        private static bool IsApproximatelyZero(double value, double epsilon = 1e-9)
        {
            return Math.Abs(value) < epsilon;
        }

        #endregion

        #region Historial y persistencia

        private static void PrintAndStoreResult(string a, string b, string op, double result)
        {
            string resultText = result.ToString("0.###############", CultureInfo.InvariantCulture);
            string line = $"{a}|{b}|{op}|{resultText}";

            _history.Add(line);
            Console.WriteLine($"= {resultText}");

            try
            {
                File.AppendAllText(HistoryFileName, line + Environment.NewLine);
            }
            catch (IOException ex)
            {
                Console.WriteLine($"[WARN] No se pudo guardar el historial: {ex.Message}");
            }
        }

        private static void SaveHistoryToTempFile()
        {
            try
            {
                var content = string.Join(",", _history.Entries);
                File.WriteAllText("leftover.tmp", content);
            }
            catch (IOException ex)
            {
                Console.WriteLine($"[WARN] No se pudo guardar leftover.tmp: {ex.Message}");
            }
        }

        #endregion
    }
}
