BadCalc_VeryBad

This project is intentionally full of terrible programming practices for a classroom exercise.
Do NOT use in production.



How to build:
dotnet build
dotnet run
